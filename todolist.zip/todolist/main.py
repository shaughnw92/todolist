import tkinter
import tkinter as tk
from tkinter import messagebox, Tk
from typing import cast


class Todos:
    def __init__(self, root: Tk, todos: list[str] | None = None, title = "To-Do List Application", can_name_files = False):
        self.root: Tk = root
        self.root.tk_setPalette(background='#f0f0f0', foreground='black')
        self.root.title(title)
        self.root.bind("<Return>", lambda event: self.on_return(event.keysym))
        self.root.bind("<Button-1>", lambda event: self.toggle_listbox(event.widget))
        self.todos: list[str] = [] if todos is None else [todo for todo in todos]
        self.filenames: list[str] = []
        self.selection: int | None = None
        self.can_name_files = can_name_files

        self.top_frame = tk.Frame(self.root, width=self.root.winfo_screenwidth())
        self.mid_frame = tk.Frame(self.root, width=self.root.winfo_screenwidth())
        self.bottom_frame = tk.Frame(self.root, background="black", width=1000)
        self.footer_frame = tk.Frame(self.root, width=self.root.winfo_screenwidth())

        self.task_entry = tk.Entry(self.top_frame, borderwidth=2, relief="solid")
        self.add_task_button = tk.Button(self.top_frame, text="Add Task", command=self.add_task)
        self.tasks_listbox = tk.Listbox(self.mid_frame, selectmode="EXTENDED", width=50, height=10)
        self.tasks_listbox.bind("<Double-Button>", lambda _event: self.delete_task())
        self.move_up_button = tk.Button(self.bottom_frame, text="Move Up", command=self.move_up)
        self.move_down_button = tk.Button(self.bottom_frame, text="Move Down", command=self.move_down)
        self.delete_task_button = tk.Button(self.footer_frame, text="Delete Task", command=self.delete_task)
        self.save_tasks_button = tk.Button(self.footer_frame, text="Save Tasks", command=self.save_tasks)
        self.load_tasks_button = tk.Button(self.footer_frame, text="Load Tasks", command=self.load_tasks)
        if todos is not None:
            self.update_tasks_listbox()
        self.create_widgets()

    def on_return(self, keysym: tkinter.Event):
        focused_tk = str(self.root.focus_get())
        is_return_on_entry = keysym == "Return" and focused_tk == ".!entry"
        if is_return_on_entry:
            self.add_task()

    def toggle_listbox(self, widget):
        event_target = str(widget)
        if "!listbox" in event_target:
            self.selection = self.tasks_listbox.curselection()[0]
        elif all(suffix not in event_target for suffix in ["!entry", "!button"]):
            self.tasks_listbox.selection_clear(0, tk.END)
            self.selection = None

    def create_widgets(self):
        print(self.root.winfo_screenwidth())
        self.top_frame.pack(fill="both", expand=True, padx=0, pady=0)
        self.mid_frame.pack(fill="both", expand=True, padx=0, pady=0, anchor="center")
        self.bottom_frame.pack(fill="both", expand=True, padx=0, pady=10)
        self.footer_frame.pack(fill="both", expand=True, padx=0, pady=10, anchor="center")

        self.task_entry.pack(pady=10)
        self.add_task_button.pack(pady=5)
        self.add_task_button.pack(pady=10)
        self.tasks_listbox.pack(padx=0)

        self.move_up_button.grid(sticky="e")
        self.move_down_button.grid(sticky="w")
        self.delete_task_button.grid(pady=10)
        self.save_tasks_button.grid(pady=10)
        self.load_tasks_button.grid(pady=10)

    def has_no_selection(self) -> bool:
        return not cast(None, self.selection)

    def add_task(self):
        task = self.task_entry.get()
        if task:
            self.todos.append(task)
            self.update_tasks_listbox()
            self.task_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Warning", "Please add a task")

    def move_up(self):
        if self.has_no_selection():
            return

        current_index = cast(int, self.selection)
        new_index = current_index - 1
        old_value = self.todos[current_index]

        self.todos.remove(old_value)
        self.todos.insert(new_index, old_value)

        self.update_tasks_listbox()
        self.tasks_listbox.select_set(new_index, new_index)

    def move_down(self):
        if self.has_no_selection():
            return

        current_index = cast(int, self.selection)
        new_index = current_index + 1
        old_value = self.todos[new_index]

        self.todos.remove(old_value)
        self.todos.insert(current_index, old_value)

        self.update_tasks_listbox()
        self.tasks_listbox.select_set(new_index, new_index)
    def delete_task(self):
        if self.has_no_selection():
            return

        if isinstance(self.selection, int):
            self.todos.pop(self.selection)
            self.update_tasks_listbox()
        else:
            messagebox.showerror("Warning", "Please select a task")


    def update_tasks_listbox(self):
        self.tasks_listbox.delete(0, tk.END)

        for index, todo in enumerate(self.todos):
            formatted_todo = f"{index + 1}: {todo}"
            self.tasks_listbox.insert(tk.END, formatted_todo)


    def simple_save_tasks(self):
        if not self.can_name_files:
            return "tasks.txt"

        file_name = input("Enter file name (leave empty for default): ")
        file_names_ln = len(self.filenames)
        return "tasks.txt" if file_names_ln == 0 else f"tasks{file_name}.txt"


    def save_tasks(self):
        file_name = self.simple_save_tasks()

        self.filenames.append(file_name)
        self.update_tasks_listbox()

        with open(file_name, "w") as file:
            file.write(f"{self.root.title()} \n")
            for index, todo in enumerate(self.todos):
                file.write(f"{index + 1}: {todo} \n")

        messagebox.showinfo("Success", "Tasks saved")


    def simple_load_tasks(self):
        if not self.can_name_files:
            return "tasks.txt"

        file_name_to_open = input("which file would you like to open (leave empty for last saved): ")
        return file_name_to_open if file_name_to_open != "" else self.filenames[-1]


    def load_tasks(self):
        file_name_to_open = self.simple_load_tasks()

        try:
            with open(file_name_to_open, "r") as file:
                self.todos = file.readlines()
            self.update_tasks_listbox()
            messagebox.showinfo("Success", "Tasks loaded")
        except FileNotFoundError:
            messagebox.showerror("Warning", "File not found")


if __name__ == "__main__":
    scotland_cities = ["glasgow", "inverness", "edinburgh", "stirling", "dunfermline", "perth", "aberdeen", "dundee"]
    roo = tk.Tk()
    app = Todos(roo, scotland_cities)
    roo.mainloop()



